var bg_default = {
  control: "Ctrl",
  alt: "Alt",
  shift: "Shift",
  meta: "Meta",
  space: "Интервал",
  enter: "Enter",
  escape: "Esc",
  tab: "Tab",
  backspace: "Backspace",
  delete: "Delete",
  insert: "Insert",
  home: "Home",
  end: "End",
  pageUp: "Page Up",
  pageDown: "Page Down"
};
export {
  bg_default as default
};
